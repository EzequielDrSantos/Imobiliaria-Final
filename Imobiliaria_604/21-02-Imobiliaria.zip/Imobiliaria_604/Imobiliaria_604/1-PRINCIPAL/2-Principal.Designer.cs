﻿namespace Imobiliaria_604
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.xuiFlatMenuStrip1 = new XanderUI.XUIFlatMenuStrip();
            this.visitaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.marcarVisitaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.editarVisitaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cancelarVisitaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.visitasMarcadasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.imoveisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.novoToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.editarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.catalogoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.vendaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.compraToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.arrendarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.investimentoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.todosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clientesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.novoToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.edittarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.procurarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.xuiFlatMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // xuiFlatMenuStrip1
            // 
            this.xuiFlatMenuStrip1.AutoSize = false;
            this.xuiFlatMenuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(49)))), ((int)(((byte)(57)))));
            this.xuiFlatMenuStrip1.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xuiFlatMenuStrip1.HoverBackColor = System.Drawing.Color.RoyalBlue;
            this.xuiFlatMenuStrip1.HoverTextColor = System.Drawing.Color.White;
            this.xuiFlatMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.xuiFlatMenuStrip1.ItemBackColor = System.Drawing.Color.DodgerBlue;
            this.xuiFlatMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.visitaToolStripMenuItem,
            this.imoveisToolStripMenuItem,
            this.catalogoToolStripMenuItem1,
            this.clientesToolStripMenuItem1});
            this.xuiFlatMenuStrip1.Location = new System.Drawing.Point(0, 0);
            this.xuiFlatMenuStrip1.Name = "xuiFlatMenuStrip1";
            this.xuiFlatMenuStrip1.SelectedBackColor = System.Drawing.Color.DarkOrchid;
            this.xuiFlatMenuStrip1.SelectedTextColor = System.Drawing.Color.White;
            this.xuiFlatMenuStrip1.SeperatorColor = System.Drawing.Color.White;
            this.xuiFlatMenuStrip1.Size = new System.Drawing.Size(1534, 100);
            this.xuiFlatMenuStrip1.TabIndex = 7;
            this.xuiFlatMenuStrip1.Text = "xuiFlatMenuStrip1";
            this.xuiFlatMenuStrip1.TextColor = System.Drawing.Color.White;
            // 
            // visitaToolStripMenuItem
            // 
            this.visitaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.marcarVisitaToolStripMenuItem1,
            this.editarVisitaToolStripMenuItem1,
            this.cancelarVisitaToolStripMenuItem,
            this.visitasMarcadasToolStripMenuItem});
            this.visitaToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.visitaToolStripMenuItem.Name = "visitaToolStripMenuItem";
            this.visitaToolStripMenuItem.Size = new System.Drawing.Size(84, 96);
            this.visitaToolStripMenuItem.Text = "Visita";
            // 
            // marcarVisitaToolStripMenuItem1
            // 
            this.marcarVisitaToolStripMenuItem1.ForeColor = System.Drawing.Color.White;
            this.marcarVisitaToolStripMenuItem1.Name = "marcarVisitaToolStripMenuItem1";
            this.marcarVisitaToolStripMenuItem1.Size = new System.Drawing.Size(274, 36);
            this.marcarVisitaToolStripMenuItem1.Text = "Marcar Visita";
            this.marcarVisitaToolStripMenuItem1.Click += new System.EventHandler(this.marcarVisitaToolStripMenuItem1_Click);
            // 
            // editarVisitaToolStripMenuItem1
            // 
            this.editarVisitaToolStripMenuItem1.ForeColor = System.Drawing.Color.White;
            this.editarVisitaToolStripMenuItem1.Name = "editarVisitaToolStripMenuItem1";
            this.editarVisitaToolStripMenuItem1.Size = new System.Drawing.Size(274, 36);
            this.editarVisitaToolStripMenuItem1.Text = "Editar Visita";
            this.editarVisitaToolStripMenuItem1.Click += new System.EventHandler(this.editarVisitaToolStripMenuItem1_Click);
            // 
            // cancelarVisitaToolStripMenuItem
            // 
            this.cancelarVisitaToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.cancelarVisitaToolStripMenuItem.Name = "cancelarVisitaToolStripMenuItem";
            this.cancelarVisitaToolStripMenuItem.Size = new System.Drawing.Size(274, 36);
            this.cancelarVisitaToolStripMenuItem.Text = "Cancelar Visita";
            this.cancelarVisitaToolStripMenuItem.Click += new System.EventHandler(this.cancelarVisitaToolStripMenuItem_Click);
            // 
            // visitasMarcadasToolStripMenuItem
            // 
            this.visitasMarcadasToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.visitasMarcadasToolStripMenuItem.Name = "visitasMarcadasToolStripMenuItem";
            this.visitasMarcadasToolStripMenuItem.Size = new System.Drawing.Size(274, 36);
            this.visitasMarcadasToolStripMenuItem.Text = "Visitas Marcadas";
            this.visitasMarcadasToolStripMenuItem.Click += new System.EventHandler(this.visitasMarcadasToolStripMenuItem_Click);
            // 
            // imoveisToolStripMenuItem
            // 
            this.imoveisToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.novoToolStripMenuItem2,
            this.editarToolStripMenuItem1});
            this.imoveisToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.imoveisToolStripMenuItem.Name = "imoveisToolStripMenuItem";
            this.imoveisToolStripMenuItem.Size = new System.Drawing.Size(106, 96);
            this.imoveisToolStripMenuItem.Text = "Imoveis";
            // 
            // novoToolStripMenuItem2
            // 
            this.novoToolStripMenuItem2.ForeColor = System.Drawing.Color.White;
            this.novoToolStripMenuItem2.Name = "novoToolStripMenuItem2";
            this.novoToolStripMenuItem2.Size = new System.Drawing.Size(162, 36);
            this.novoToolStripMenuItem2.Text = "Novo";
            this.novoToolStripMenuItem2.Click += new System.EventHandler(this.novoToolStripMenuItem2_Click);
            // 
            // editarToolStripMenuItem1
            // 
            this.editarToolStripMenuItem1.ForeColor = System.Drawing.Color.White;
            this.editarToolStripMenuItem1.Name = "editarToolStripMenuItem1";
            this.editarToolStripMenuItem1.Size = new System.Drawing.Size(162, 36);
            this.editarToolStripMenuItem1.Text = "Editar";
            this.editarToolStripMenuItem1.Click += new System.EventHandler(this.editarToolStripMenuItem1_Click);
            // 
            // catalogoToolStripMenuItem1
            // 
            this.catalogoToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vendaToolStripMenuItem1,
            this.compraToolStripMenuItem1,
            this.arrendarToolStripMenuItem,
            this.investimentoToolStripMenuItem1,
            this.todosToolStripMenuItem});
            this.catalogoToolStripMenuItem1.ForeColor = System.Drawing.Color.White;
            this.catalogoToolStripMenuItem1.Name = "catalogoToolStripMenuItem1";
            this.catalogoToolStripMenuItem1.Size = new System.Drawing.Size(120, 96);
            this.catalogoToolStripMenuItem1.Text = "Catalogo";
            // 
            // vendaToolStripMenuItem1
            // 
            this.vendaToolStripMenuItem1.ForeColor = System.Drawing.Color.White;
            this.vendaToolStripMenuItem1.Name = "vendaToolStripMenuItem1";
            this.vendaToolStripMenuItem1.Size = new System.Drawing.Size(234, 36);
            this.vendaToolStripMenuItem1.Text = "Venda";
            this.vendaToolStripMenuItem1.Click += new System.EventHandler(this.vendaToolStripMenuItem1_Click);
            // 
            // compraToolStripMenuItem1
            // 
            this.compraToolStripMenuItem1.ForeColor = System.Drawing.Color.White;
            this.compraToolStripMenuItem1.Name = "compraToolStripMenuItem1";
            this.compraToolStripMenuItem1.Size = new System.Drawing.Size(234, 36);
            this.compraToolStripMenuItem1.Text = "Compra";
            this.compraToolStripMenuItem1.Click += new System.EventHandler(this.compraToolStripMenuItem1_Click);
            // 
            // arrendarToolStripMenuItem
            // 
            this.arrendarToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.arrendarToolStripMenuItem.Name = "arrendarToolStripMenuItem";
            this.arrendarToolStripMenuItem.Size = new System.Drawing.Size(234, 36);
            this.arrendarToolStripMenuItem.Text = "Arrendar";
            this.arrendarToolStripMenuItem.Click += new System.EventHandler(this.arrendarToolStripMenuItem_Click);
            // 
            // investimentoToolStripMenuItem1
            // 
            this.investimentoToolStripMenuItem1.ForeColor = System.Drawing.Color.White;
            this.investimentoToolStripMenuItem1.Name = "investimentoToolStripMenuItem1";
            this.investimentoToolStripMenuItem1.Size = new System.Drawing.Size(234, 36);
            this.investimentoToolStripMenuItem1.Text = "Investimento";
            this.investimentoToolStripMenuItem1.Click += new System.EventHandler(this.investimentoToolStripMenuItem1_Click);
            // 
            // todosToolStripMenuItem
            // 
            this.todosToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.todosToolStripMenuItem.Name = "todosToolStripMenuItem";
            this.todosToolStripMenuItem.Size = new System.Drawing.Size(234, 36);
            this.todosToolStripMenuItem.Text = "Todos";
            this.todosToolStripMenuItem.Click += new System.EventHandler(this.todosToolStripMenuItem_Click);
            // 
            // clientesToolStripMenuItem1
            // 
            this.clientesToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.novoToolStripMenuItem3,
            this.edittarToolStripMenuItem,
            this.procurarToolStripMenuItem1});
            this.clientesToolStripMenuItem1.ForeColor = System.Drawing.Color.White;
            this.clientesToolStripMenuItem1.Name = "clientesToolStripMenuItem1";
            this.clientesToolStripMenuItem1.Size = new System.Drawing.Size(109, 96);
            this.clientesToolStripMenuItem1.Text = "Clientes";
            // 
            // novoToolStripMenuItem3
            // 
            this.novoToolStripMenuItem3.ForeColor = System.Drawing.Color.White;
            this.novoToolStripMenuItem3.Name = "novoToolStripMenuItem3";
            this.novoToolStripMenuItem3.Size = new System.Drawing.Size(188, 36);
            this.novoToolStripMenuItem3.Text = "Novo";
            this.novoToolStripMenuItem3.Click += new System.EventHandler(this.novoToolStripMenuItem3_Click);
            // 
            // edittarToolStripMenuItem
            // 
            this.edittarToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.edittarToolStripMenuItem.Name = "edittarToolStripMenuItem";
            this.edittarToolStripMenuItem.Size = new System.Drawing.Size(188, 36);
            this.edittarToolStripMenuItem.Text = "Editar ";
            this.edittarToolStripMenuItem.Click += new System.EventHandler(this.edittarToolStripMenuItem_Click);
            // 
            // procurarToolStripMenuItem1
            // 
            this.procurarToolStripMenuItem1.ForeColor = System.Drawing.Color.White;
            this.procurarToolStripMenuItem1.Name = "procurarToolStripMenuItem1";
            this.procurarToolStripMenuItem1.Size = new System.Drawing.Size(188, 36);
            this.procurarToolStripMenuItem1.Text = "Procurar";
            this.procurarToolStripMenuItem1.Click += new System.EventHandler(this.procurarToolStripMenuItem1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = global::Imobiliaria_604.Properties.Resources.ReMIN;
            this.pictureBox1.Location = new System.Drawing.Point(1412, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(105, 100);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(49)))), ((int)(((byte)(57)))));
            this.ClientSize = new System.Drawing.Size(1534, 938);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.xuiFlatMenuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.Name = "Form2";
            this.Text = "PRINCIPAL";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.xuiFlatMenuStrip1.ResumeLayout(false);
            this.xuiFlatMenuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox1;
        private XanderUI.XUIFlatMenuStrip xuiFlatMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem visitaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem marcarVisitaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem editarVisitaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem imoveisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem novoToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem editarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem catalogoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem vendaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem compraToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem arrendarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem investimentoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem todosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clientesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem novoToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem edittarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem procurarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cancelarVisitaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem visitasMarcadasToolStripMenuItem;
    }
}