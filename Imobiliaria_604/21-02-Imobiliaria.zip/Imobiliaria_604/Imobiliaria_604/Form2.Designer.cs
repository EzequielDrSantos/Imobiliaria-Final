﻿namespace Imobiliaria_604
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.xuiFlatMenuStrip1 = new XanderUI.XUIFlatMenuStrip();
            this.iMOVEISToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nOVOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eDITARToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rEMOVERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mARCARVISITAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mARCARVISITAToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.eDITARVISITAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cANCELARVISITAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cATALAGOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vENDAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cOMPRAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iNVESTIMENTOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tODASToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cLIENTESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nOVOToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.eDITARINFORMAÇÕESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pROCURARToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rEMOVERToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.button1 = new System.Windows.Forms.Button();
            this.xuiFlatMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // xuiFlatMenuStrip1
            // 
            this.xuiFlatMenuStrip1.BackColor = System.Drawing.Color.DodgerBlue;
            this.xuiFlatMenuStrip1.HoverBackColor = System.Drawing.Color.RoyalBlue;
            this.xuiFlatMenuStrip1.HoverTextColor = System.Drawing.Color.White;
            this.xuiFlatMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.xuiFlatMenuStrip1.ItemBackColor = System.Drawing.Color.DodgerBlue;
            this.xuiFlatMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.iMOVEISToolStripMenuItem,
            this.mARCARVISITAToolStripMenuItem,
            this.cATALAGOToolStripMenuItem,
            this.cLIENTESToolStripMenuItem});
            this.xuiFlatMenuStrip1.Location = new System.Drawing.Point(0, 0);
            this.xuiFlatMenuStrip1.Name = "xuiFlatMenuStrip1";
            this.xuiFlatMenuStrip1.SelectedBackColor = System.Drawing.Color.DarkOrchid;
            this.xuiFlatMenuStrip1.SelectedTextColor = System.Drawing.Color.White;
            this.xuiFlatMenuStrip1.SeperatorColor = System.Drawing.Color.White;
            this.xuiFlatMenuStrip1.Size = new System.Drawing.Size(800, 30);
            this.xuiFlatMenuStrip1.TabIndex = 3;
            this.xuiFlatMenuStrip1.Text = "xuiFlatMenuStrip1";
            this.xuiFlatMenuStrip1.TextColor = System.Drawing.Color.White;
            // 
            // iMOVEISToolStripMenuItem
            // 
            this.iMOVEISToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nOVOToolStripMenuItem,
            this.eDITARToolStripMenuItem,
            this.rEMOVERToolStripMenuItem});
            this.iMOVEISToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.iMOVEISToolStripMenuItem.Name = "iMOVEISToolStripMenuItem";
            this.iMOVEISToolStripMenuItem.Size = new System.Drawing.Size(80, 26);
            this.iMOVEISToolStripMenuItem.Text = "IMOVEIS";
            // 
            // nOVOToolStripMenuItem
            // 
            this.nOVOToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.nOVOToolStripMenuItem.Name = "nOVOToolStripMenuItem";
            this.nOVOToolStripMenuItem.Size = new System.Drawing.Size(159, 26);
            this.nOVOToolStripMenuItem.Text = "NOVO";
            // 
            // eDITARToolStripMenuItem
            // 
            this.eDITARToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.eDITARToolStripMenuItem.Name = "eDITARToolStripMenuItem";
            this.eDITARToolStripMenuItem.Size = new System.Drawing.Size(159, 26);
            this.eDITARToolStripMenuItem.Text = "EDITAR";
            // 
            // rEMOVERToolStripMenuItem
            // 
            this.rEMOVERToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.rEMOVERToolStripMenuItem.Name = "rEMOVERToolStripMenuItem";
            this.rEMOVERToolStripMenuItem.Size = new System.Drawing.Size(159, 26);
            this.rEMOVERToolStripMenuItem.Text = "REMOVER";
            // 
            // mARCARVISITAToolStripMenuItem
            // 
            this.mARCARVISITAToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mARCARVISITAToolStripMenuItem1,
            this.eDITARVISITAToolStripMenuItem,
            this.cANCELARVISITAToolStripMenuItem});
            this.mARCARVISITAToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.mARCARVISITAToolStripMenuItem.Name = "mARCARVISITAToolStripMenuItem";
            this.mARCARVISITAToolStripMenuItem.Size = new System.Drawing.Size(73, 26);
            this.mARCARVISITAToolStripMenuItem.Text = "VISITAS";
            // 
            // mARCARVISITAToolStripMenuItem1
            // 
            this.mARCARVISITAToolStripMenuItem1.ForeColor = System.Drawing.Color.White;
            this.mARCARVISITAToolStripMenuItem1.Name = "mARCARVISITAToolStripMenuItem1";
            this.mARCARVISITAToolStripMenuItem1.Size = new System.Drawing.Size(211, 26);
            this.mARCARVISITAToolStripMenuItem1.Text = "MARCAR VISITA";
            // 
            // eDITARVISITAToolStripMenuItem
            // 
            this.eDITARVISITAToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.eDITARVISITAToolStripMenuItem.Name = "eDITARVISITAToolStripMenuItem";
            this.eDITARVISITAToolStripMenuItem.Size = new System.Drawing.Size(211, 26);
            this.eDITARVISITAToolStripMenuItem.Text = "EDITAR VISITA";
            // 
            // cANCELARVISITAToolStripMenuItem
            // 
            this.cANCELARVISITAToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.cANCELARVISITAToolStripMenuItem.Name = "cANCELARVISITAToolStripMenuItem";
            this.cANCELARVISITAToolStripMenuItem.Size = new System.Drawing.Size(211, 26);
            this.cANCELARVISITAToolStripMenuItem.Text = "CANCELAR VISITA";
            // 
            // cATALAGOToolStripMenuItem
            // 
            this.cATALAGOToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vENDAToolStripMenuItem,
            this.cOMPRAToolStripMenuItem,
            this.iNVESTIMENTOToolStripMenuItem,
            this.tODASToolStripMenuItem});
            this.cATALAGOToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.cATALAGOToolStripMenuItem.Name = "cATALAGOToolStripMenuItem";
            this.cATALAGOToolStripMenuItem.Size = new System.Drawing.Size(96, 26);
            this.cATALAGOToolStripMenuItem.Text = "CATALAGO";
            // 
            // vENDAToolStripMenuItem
            // 
            this.vENDAToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.vENDAToolStripMenuItem.Name = "vENDAToolStripMenuItem";
            this.vENDAToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.vENDAToolStripMenuItem.Text = "VENDA ";
            // 
            // cOMPRAToolStripMenuItem
            // 
            this.cOMPRAToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.cOMPRAToolStripMenuItem.Name = "cOMPRAToolStripMenuItem";
            this.cOMPRAToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.cOMPRAToolStripMenuItem.Text = "COMPRA";
            // 
            // iNVESTIMENTOToolStripMenuItem
            // 
            this.iNVESTIMENTOToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.iNVESTIMENTOToolStripMenuItem.Name = "iNVESTIMENTOToolStripMenuItem";
            this.iNVESTIMENTOToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.iNVESTIMENTOToolStripMenuItem.Text = "INVESTIMENTO";
            // 
            // tODASToolStripMenuItem
            // 
            this.tODASToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.tODASToolStripMenuItem.Name = "tODASToolStripMenuItem";
            this.tODASToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.tODASToolStripMenuItem.Text = "TUDO";
            // 
            // cLIENTESToolStripMenuItem
            // 
            this.cLIENTESToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nOVOToolStripMenuItem1,
            this.eDITARINFORMAÇÕESToolStripMenuItem,
            this.pROCURARToolStripMenuItem,
            this.rEMOVERToolStripMenuItem1});
            this.cLIENTESToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.cLIENTESToolStripMenuItem.Name = "cLIENTESToolStripMenuItem";
            this.cLIENTESToolStripMenuItem.Size = new System.Drawing.Size(86, 26);
            this.cLIENTESToolStripMenuItem.Text = "CLIENTES";
            // 
            // nOVOToolStripMenuItem1
            // 
            this.nOVOToolStripMenuItem1.ForeColor = System.Drawing.Color.White;
            this.nOVOToolStripMenuItem1.Name = "nOVOToolStripMenuItem1";
            this.nOVOToolStripMenuItem1.Size = new System.Drawing.Size(246, 26);
            this.nOVOToolStripMenuItem1.Text = "NOVO ";
            // 
            // eDITARINFORMAÇÕESToolStripMenuItem
            // 
            this.eDITARINFORMAÇÕESToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.eDITARINFORMAÇÕESToolStripMenuItem.Name = "eDITARINFORMAÇÕESToolStripMenuItem";
            this.eDITARINFORMAÇÕESToolStripMenuItem.Size = new System.Drawing.Size(246, 26);
            this.eDITARINFORMAÇÕESToolStripMenuItem.Text = "EDITAR INFORMAÇÕES";
            // 
            // pROCURARToolStripMenuItem
            // 
            this.pROCURARToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.pROCURARToolStripMenuItem.Name = "pROCURARToolStripMenuItem";
            this.pROCURARToolStripMenuItem.Size = new System.Drawing.Size(246, 26);
            this.pROCURARToolStripMenuItem.Text = "PROCURAR";
            // 
            // rEMOVERToolStripMenuItem1
            // 
            this.rEMOVERToolStripMenuItem1.ForeColor = System.Drawing.Color.White;
            this.rEMOVERToolStripMenuItem1.Name = "rEMOVERToolStripMenuItem1";
            this.rEMOVERToolStripMenuItem1.Size = new System.Drawing.Size(246, 26);
            this.rEMOVERToolStripMenuItem1.Text = "REMOVER ";
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Location = new System.Drawing.Point(725, 424);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "SAIR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.xuiFlatMenuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.xuiFlatMenuStrip1;
            this.Name = "Form2";
            this.Text = "Form2";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.xuiFlatMenuStrip1.ResumeLayout(false);
            this.xuiFlatMenuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private XanderUI.XUIFlatMenuStrip xuiFlatMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem iMOVEISToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nOVOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eDITARToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rEMOVERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mARCARVISITAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mARCARVISITAToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem eDITARVISITAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cANCELARVISITAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cATALAGOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vENDAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cOMPRAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iNVESTIMENTOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tODASToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStripMenuItem cLIENTESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nOVOToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem eDITARINFORMAÇÕESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pROCURARToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rEMOVERToolStripMenuItem1;
    }
}