﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Imobiliaria_604
{
    internal class Global
    {
        public static string perfil;
        

    }
}
//---------------------------------------
//- Remover Imovel                      -
//- Form1 f5 = new Form1();             -
//- f5.MdiParent = this;                -
//- f5.Show();                          -
//-                                     -
//- Remver Cliente                      -
//- Form7 f8 = new Form7();             -
//- f8.MdiParent = this;                -
//- f8.Show();                          -
//---------------------------------------
//Beja
//
//    //Aljustrel
//    //Almodôvar
//    //Alvito
//    //Barrancos
//    //Beja    
//    //Castro Verde
//    //Cuba    
//    //Ferreira do Alentejo
//    //Mértola
//    //Moura
//    //Odemira
//    //Ourique
//    //Serpa
//    //Vidigueira
//

//Évora
//
//    //comboBox2.Text == 
//    //Alandroal
//    //Arraiolos
//    //Borba
//    //Estremoz
//    //Évora
//    //Montemor - o - Novo
//    //Mora
//    //Mourão
//    //Portel
//    //Redondo
//    //Reguengos de Monsaraz
//    //Vendas Novas
//    //Viana do Alentejo
//    //Vila Viçosa     
//

//Santarém
//
//    
//    //Abrantes
//    //Almeirim
//    //Cartaxo
//    //Entroncamento
//    //Fátima(Ourém)
//    //Ourém
//    //Rio Maior
//    //Samora Correia(Benavente)
//    //Santarém
//    //Tomar
//    //Torres Novas
//

//Castelo Branco
//
//    //comboBox2.Text == 
//    //Belmonte
//    //Castelo Branco
//    //Covilhã
//    //Fundão
//    //Idanha - a - Nova
//    //Oleiros
//    //Penamacor
//    //Proença - a - Nova
//    //Sertã
//    //Vila de Rei
//    //Vila Velha de Ródão
//}

//Bragança
//
//    //comboBox2.Text == 
//    //Alfândega da Fé
//    //Bragança
//    //Carrazeda de Ansiães
//    //Freixo de Espada à Cinta
//    //Macedo de Cavaleiros
//    //Miranda do Douro
//    //Mirandela
//    //Mogadouro
//    //Torre de Moncorvo
//    //Vila Flor
//    //Vimioso
//    //Vinhais
//

//Portalegre
//
//    //Elvas
//    //Portalegre
//    //Ponte de Sor
//    //Campo Maior
//    //Nisa
//    //Castelo de Vide
//    //Alter do Chão
//    //Arronches
//    //Sousel
//    //Fronteira
//    //Avis
//    //Crato
//    //Gavião
//    //Monforte
//    //Marvão
//

//Guarda
//
//    //Aguiar da Beira
//    //Almeida
//    //Celorico da Beira
//    //Figueira de Castelo Rodrigo
//    //Fornos de Algodres
//    //Gouveia
//    //Guarda
//    //Manteigas
//    //Mêda
//    //Pinhel
//    //Sabugal
//    //Seia
//    //Trancoso
//    //Vila Nova de Foz Côa
//

//Setúbal
//
//    //Alcácer do Sal
//    // Alcochete         
//    //Almada
//    // Barreiro
//    // Grândola
//    // Moita
//    // Montijo
//    // Palmela
//    // Santiago do Cacém
//    // Seixal
//    // Sesimbra
//    // Setúbal
//    // Sines
//

//Viseu
//
//    //Armamar
//    //Carregal do Sal
//    //Castro Daire
//    //Cinfães
//    //Lamego
//    //Mangualde
//    //Moimenta da Beira
//    //Mortágua
//    //Nelas
//    //Oliveira de Frades
//    //Penalva do Castelo
//    //Penedono
//    // Resende
//    //Santa Comba Dão
//    //São João da Pesqueira
//    //São Pedro do Sul
//    //Sátão
//    //Sernancelhe
//    //Tabuaço
//    //Tarouca
//    //Tondela
//    //Vila Nova de Paiva
//    //Viseu
//    //Vouzela
//

//Faro
//
//    //Vila Real
//    //Albufeira
//    //Alcoutim
//    //Aljezur
//    //Castro Marim
//    //Faro
//    //Lagoa
//    //Lagos
//    //Loulé
//    //Monchique
//    //Olhão
//    //Portimão
//    //São Brás de Alportel
//    //Silves
//    //Tavira
//    //Vila do Bispo
//    //Vila Real de Santo António
//

//Vila Real
//
//    //Alijó
//    //Boticas
//    //Chaves
//    //Mesão Frio
//    //Mondim de Basto
//    //Montalegre
//    //Murça
//    //Peso da Régua
//    //Ribeira de Pena
//    //Sabrosa
//    //Santa Marta de Penaguião
//    //Valpaços
//    //Vila Pouca de Aguiar
//    //Vila Real
//

//Coimbra
//
//    //Cantanhede
//    //Coimbra
//    //Condeixa - a - Nova
//    //Figueira da Foz
//    //Mira
//    //Montemor - o - Velho
//    //Penacova
//    //Soure
//    //Arganil
//    //Góis
//    //Lousã
//    //Miranda do Corvo
//    //Oliveira do Hospital
//    //Pampilhosa da Serra
//    //Penela
//    //Tábua
//   //Vila Nova de Poiares
//

//Leiria
//
//    //Alcobaça
//    //Alvaiázere
//    //Ansião
//    //Batalha
//    //Bombarral
//    //Caldas da Rainha
//    //Castanheira de Pera
//    //Figueiró dos Vinhos
//    //Leiria
//    //Marinha Grande
//    //Nazaré
//    //Óbidos
//    //Pedrógão Grande
//    //Peniche
//    //Pombal
//    //Porto de Mós
//

//Aveiro
//
//    //Águeda
//    // Albergaria - a - Velha
//    // Anadia
//    // Arouca
//    // Aveiro
//    // Castelo de Paiva
//    // Espinho
//    // Estarreja
//    // Ílhavo
//    // Mealhada
//    // Murtosa
//    // Oliveira de Azeméis
//    // Oliveira do Bairro
//    // Ovar
//    // Santa Maria da Feira
//    // São João da Madeira
//    // Sever do Vouga
//    // Vagos
//    //Vale de Cambra
//

//Lisboa
//
//    //Alenquer
//    //Amadora
//    //Arruda dos Vinhos
//    //Azambuja
//    //Cadaval
//    //Cascais
//    //Lisboa
//    //Loures
//    //Lourinhã
//    //Mafra
//    // Odivelas
//    //Oeiras
//    //Sintra
//    // Sobral de Monte Agraço
//    // Torres Vedras
//    // Vila Franca de Xira
//

//Braga
//
//    //Amares
//    //Barcelos
//    //Braga
//    //Cabeceiras de Basto
//    //Celorico de Basto
//    //Esposende
//    //Fafe
//    //Guimarães
//    //Póvoa de Lanhoso
//    //Terras de Bouro
//    //Vieira do Minho
//    //Vila Nova de Famalicão
//    //Vila Verde
//    //Vizela
//

//Porto
//
//    //Amarante
//    //Baião
//    //Felgueiras
//    //Gondomar
//    //Lousada
//    //Maia
//    //Marco de Canaveses
//    //Matosinhos
//    //Paços de Ferreira
//    //Amarante
//    //Baião
//    //Felgueiras
//    //Gondomar
//    //Lousada
//    //Maia
//    //Marco de Canaveses
//    //Matosinhos
//    //Paços de Ferreira
//

//Viana do Castelo
//
//    //Viana do Castelo
//    //Ponte de Lima
//    //Arcos de Valdevez
//    //Monção
//    //Caminha
//    //Valença
//    //Ponte da Barca
//    //Vila Nova de Cerveira
//    //Paredes de Coura
//    //Melgaço
//